import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, TextInput } from 'react-native';

const App = () => {
  const [input, setInput] = useState('');

  const handleClick = (value) => {
    setInput((prev) => prev + value);
  };

  const calcular = () => {
    try {
      setInput(eval(input).toString());
    } catch {
      setInput('Erro');
    }
  };

  const limpar = () => {
    setInput('');
  };

  return (
    <View style={styles.container}>
      <TextInput style={styles.input} value={input} editable={false} />
      <View style={styles.buttonWrapper}>
        <TouchableOpacity style={styles.buttonStyle1} onPress={() => handleClick("1")}>
          <Text style={styles.buttonText}>1</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.buttonStyle1} onPress={() => handleClick("2")}>
          <Text style={styles.buttonText}>2</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.buttonStyle1} onPress={() => handleClick("3")}>
          <Text style={styles.buttonText}>3</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.buttonStyle1} onPress={() => handleClick("+")}>
          <Text style={styles.buttonText2}>+</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.buttonWrapper}>
        <TouchableOpacity style={styles.buttonStyle1} onPress={() => handleClick("4")}>
          <Text style={styles.buttonText}>4</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.buttonStyle1} onPress={() => handleClick("5")}>
          <Text style={styles.buttonText}>5</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.buttonStyle1} onPress={() => handleClick("6")}>
          <Text style={styles.buttonText}>6</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.buttonStyle1} onPress={() => handleClick("-")}>
          <Text style={styles.buttonText2}>-</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.buttonWrapper}>
        <TouchableOpacity style={styles.buttonStyle1} onPress={() => handleClick("7")}>
          <Text style={styles.buttonText}>7</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.buttonStyle1} onPress={() => handleClick("8")}>
          <Text style={styles.buttonText}>8</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.buttonStyle1} onPress={() => handleClick("9")}>
          <Text style={styles.buttonText}>9</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.buttonStyle1} onPress={() => handleClick("*")}>
          <Text style={styles.buttonText2}>*</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.buttonWrapper}>
              <TouchableOpacity style={styles.buttonStyle1} onPress={() => handleClick("/")}>
          <Text style={styles.buttonText2}>/</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.buttonStyle1} onPress={() => handleClick("0")}>
          <Text style={styles.buttonText}>0</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.buttonStyle1} onPress={limpar}>
          <Text style={styles.buttonText2}>C</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.buttonStyle2} onPress={calcular}>
          <Text style={styles.buttonText3}>=</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 15,
    backgroundColor: 'black',
    justifyContent: 'end',
    borderRadius: 30
  },
  input: {
    height: 60,
    width:'',
    borderWidth: 1,
    marginBottom: 30,
    textAlign: 'right',
    fontSize: 70,
    paddingRight: '5%',
    color: '#DCDCDC',
    backgroundColor:'black',
    fontWeight:'800',
    fontFamily: 'Andale Mono, monospace',
    borderStyle: 'solid',
    borderBottomWidth: '4px',
   borderBottomColor: 'white'
  },
  buttonWrapper: {
    flexDirection: "row",
    justifyContent: 'space-between',
    marginBottom: 10,
    marginRight: 40
  },
  buttonStyle1: {
    borderRadius: 20,
    width: '26%',
    height: 70,
    backgroundColor: '#363636',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
    
  },
  buttonStyle2: {
    borderRadius: 20,
    width: '26%',
    height: 70,
    backgroundColor: '#FF8C10',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10
  },

  buttonText: {
    fontSize: 30,
    color: 'white',
    fontWeight: 500,
    justifySelf: 'center'
  },
    buttonText2: {
    fontSize: 30,
    color: '#FF8C00',
    fontWeight: 999,
    marginBottom: 4
  },
    buttonText3: {
    fontSize: 37,
    color: 'white',
    fontWeight: 999,
    alignSelf:'center',
    justifySelf:'center',
    marginBottom:8
  },
});

export default App;
